import { TextFilterPipe } from './text-filter.pipe';

describe('TextFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TextFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
