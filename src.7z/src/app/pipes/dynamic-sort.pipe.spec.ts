import { DynamicSortPipe } from './dynamic-sort.pipe';

describe('DynamicSortPipe', () => {
  it('create an instance', () => {
    const pipe = new DynamicSortPipe();
    expect(pipe).toBeTruthy();
  });
});
